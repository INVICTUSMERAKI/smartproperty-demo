'use strict';
const http   = require('http');
const crypto = require('crypto');
const fs     = require('fs');
const path   = require('path');
const url    = require('url');

const PORT    = 3000;
const PUBLIC  = path.join(__dirname, '..', 'public');

// ── In-memory database ────────────────────────────────────────
const DB = {
  organizations: [], users: [], properties: [], blocks: [],
  units: [], leases: [], invoices: [], payments: [],
  maintenance: [], meters: [], expenses: [],
};

function uid()  { return crypto.randomUUID(); }
function hashPw(pw) { return crypto.createHash('sha256').update(pw+'sp_salt_2024').digest('hex'); }
function checkPw(pw,h) { return hashPw(pw)===h; }
function b64(s) { return Buffer.from(s).toString('base64url'); }

function makeToken(payload) {
  const h = b64(JSON.stringify({alg:'HS256',typ:'JWT'}));
  const p = b64(JSON.stringify({...payload, exp: Date.now()+86400000*7}));
  const s = crypto.createHmac('sha256','sp_demo_secret_key_2024').update(h+'.'+p).digest('base64url');
  return h+'.'+p+'.'+s;
}
function verifyToken(token) {
  try {
    const [h,p,s] = token.split('.');
    const exp = crypto.createHmac('sha256','sp_demo_secret_key_2024').update(h+'.'+p).digest('base64url');
    if (s!==exp) return null;
    const payload = JSON.parse(Buffer.from(p,'base64').toString());
    return payload.exp < Date.now() ? null : payload;
  } catch { return null; }
}

function getAuth(req) {
  const h = req.headers.authorization||'';
  return h.startsWith('Bearer ') ? verifyToken(h.slice(7)) : null;
}
function byOrg(arr,orgId) { return arr.filter(x=>x.organization_id===orgId); }

function json(res, data, status=200) {
  res.writeHead(status, {
    'Content-Type':'application/json',
    'Access-Control-Allow-Origin':'*',
    'Access-Control-Allow-Headers':'Content-Type,Authorization',
    'Access-Control-Allow-Methods':'GET,POST,PUT,PATCH,DELETE,OPTIONS',
  });
  res.end(JSON.stringify(data));
}

function parseBody(req) {
  return new Promise(resolve => {
    let b='';
    req.on('data',c=>b+=c);
    req.on('end',()=>{ try{resolve(JSON.parse(b||'{}'));}catch{resolve({});} });
  });
}

function servFile(res, filePath, ct='text/html') {
  try {
    const content = fs.readFileSync(filePath);
    res.writeHead(200,{'Content-Type':ct});
    res.end(content);
  } catch {
    res.writeHead(404);
    res.end('Not found');
  }
}

// ── Seed demo data ────────────────────────────────────────────
function seed() {
  const orgId=uid(), u1=uid(), u2=uid(), t1=uid(), t2=uid(), t3=uid();
  const p1=uid(), p2=uid(), b1=uid();
  const un1=uid(), un2=uid(), un3=uid(), un4=uid(), un5=uid();
  const l1=uid(), l2=uid();
  const i1=uid(), i2=uid(), i3=uid(), pay1=uid();
  const ago = d => new Date(Date.now()-d*86400000).toISOString();

  DB.organizations.push({id:orgId, name:'Westlands Properties Ltd', slug:'westlands', email:'info@westlands.co.ke', phone:'+254 712 345 678', city:'Nairobi', country:'Kenya', currency:'KES', timezone:'Africa/Nairobi', subscription_plan:'professional', subscription_status:'active', mpesa_shortcode:'174379', created_at:ago(90)});
  DB.users.push({id:u1, organization_id:orgId, email:'admin@demo.com', password_hash:hashPw('demo1234'), first_name:'James', last_name:'Kariuki', role:'super_admin', phone:'+254712000001', is_active:true, created_at:ago(90)});
  DB.users.push({id:u2, organization_id:orgId, email:'manager@demo.com', password_hash:hashPw('demo1234'), first_name:'Grace', last_name:'Wanjiru', role:'property_manager', phone:'+254712000002', is_active:true, created_at:ago(90)});
  DB.users.push({id:t1, organization_id:orgId, email:'jane@tenant.com', password_hash:hashPw('demo1234'), first_name:'Jane', last_name:'Wanjiku', role:'tenant', phone:'+254722111001', national_id:'28741234', kra_pin:'A001234567B', is_active:true, created_at:ago(60)});
  DB.users.push({id:t2, organization_id:orgId, email:'brian@tenant.com', password_hash:hashPw('demo1234'), first_name:'Brian', last_name:'Mwangi', role:'tenant', phone:'+254733222002', national_id:'31852345', kra_pin:'B002345678C', is_active:true, created_at:ago(50)});
  DB.users.push({id:t3, organization_id:orgId, email:'amina@tenant.com', password_hash:hashPw('demo1234'), first_name:'Amina', last_name:'Hassan', role:'tenant', phone:'+254711333003', national_id:'22963456', kra_pin:'C003456789D', is_active:true, created_at:ago(45)});

  DB.properties.push({id:p1, organization_id:orgId, name:'Westlands Heights', code:'WH-001', type:'residential', address:'123 Westlands Road', city:'Nairobi', country:'Kenya', total_units:3, occupied_units:2, current_valuation:45000000, is_active:true, created_at:ago(60)});
  DB.properties.push({id:p2, organization_id:orgId, name:'Kilimani Court', code:'KC-001', type:'commercial', address:'45 Kilimani Avenue', city:'Nairobi', country:'Kenya', total_units:2, occupied_units:1, current_valuation:28000000, is_active:true, created_at:ago(55)});
  DB.blocks.push({id:b1, property_id:p1, organization_id:orgId, name:'Block A', floors:4, total_units:3, created_at:ago(60)});

  DB.units.push({id:un1, block_id:b1, property_id:p1, organization_id:orgId, unit_number:'A101', floor_number:1, type:'2br', status:'occupied', monthly_rent:45000, deposit_amount:90000, bedrooms:2, bathrooms:2, size_sqm:85, current_tenant_id:t1, current_lease_id:l1, water_meter_number:'WTR001', electricity_meter_number:'ELC001', is_active:true, created_at:ago(60)});
  DB.units.push({id:un2, block_id:b1, property_id:p1, organization_id:orgId, unit_number:'A204', floor_number:2, type:'3br', status:'occupied', monthly_rent:65000, deposit_amount:130000, bedrooms:3, bathrooms:2, size_sqm:110, current_tenant_id:t2, current_lease_id:l2, water_meter_number:'WTR002', electricity_meter_number:'ELC002', is_active:true, created_at:ago(55)});
  DB.units.push({id:un3, block_id:b1, property_id:p1, organization_id:orgId, unit_number:'A305', floor_number:3, type:'1br', status:'vacant', monthly_rent:28000, deposit_amount:56000, bedrooms:1, bathrooms:1, size_sqm:52, is_active:true, created_at:ago(50)});
  DB.units.push({id:un4, property_id:p2, organization_id:orgId, unit_number:'GF-01', floor_number:0, type:'shop', status:'occupied', monthly_rent:85000, deposit_amount:170000, current_tenant_id:t3, is_active:true, created_at:ago(45)});
  DB.units.push({id:un5, property_id:p2, organization_id:orgId, unit_number:'FF-01', floor_number:1, type:'office', status:'vacant', monthly_rent:55000, deposit_amount:110000, is_active:true, created_at:ago(45)});

  DB.leases.push({id:l1, organization_id:orgId, unit_id:un1, tenant_id:t1, property_id:p1, lease_number:'LSE-2024-001', status:'active', start_date:'2024-01-01', end_date:'2024-12-31', monthly_rent:45000, deposit_amount:90000, deposit_paid:90000, rent_due_day:5, grace_period_days:5, late_fee_type:'percentage', late_fee_value:10, created_at:ago(60)});
  DB.leases.push({id:l2, organization_id:orgId, unit_id:un2, tenant_id:t2, property_id:p1, lease_number:'LSE-2024-002', status:'active', start_date:'2024-02-01', end_date:'2025-01-31', monthly_rent:65000, deposit_amount:130000, deposit_paid:130000, rent_due_day:5, grace_period_days:3, late_fee_type:'fixed', late_fee_value:2000, created_at:ago(55)});

  const pl1='http://localhost:'+PORT+'/pay/INV-2024-00001';
  const pl2='http://localhost:'+PORT+'/pay/INV-2024-00002';
  const pl3='http://localhost:'+PORT+'/pay/INV-2024-00003';
  DB.invoices.push({id:i1, organization_id:orgId, invoice_number:'INV-2024-00001', type:'rent', status:'paid', tenant_id:t1, unit_id:un1, lease_id:l1, property_id:p1, amount:45000, total_amount:45000, amount_paid:45000, balance_due:0, currency:'KES', issue_date:'2024-06-01', due_date:'2024-06-05', period_start:'2024-06-01', period_end:'2024-06-30', description:'Rent for June 2024 - Unit A101', payment_link:pl1, paid_at:ago(20), created_at:ago(30)});
  DB.invoices.push({id:i2, organization_id:orgId, invoice_number:'INV-2024-00002', type:'rent', status:'overdue', tenant_id:t2, unit_id:un2, lease_id:l2, property_id:p1, amount:65000, total_amount:65000, amount_paid:0, balance_due:65000, currency:'KES', issue_date:'2024-06-01', due_date:'2024-06-05', period_start:'2024-06-01', period_end:'2024-06-30', description:'Rent for June 2024 - Unit A204', payment_link:pl2, created_at:ago(30)});
  DB.invoices.push({id:i3, organization_id:orgId, invoice_number:'INV-2024-00003', type:'water', status:'sent', tenant_id:t3, unit_id:un4, property_id:p2, amount:3200, total_amount:3200, amount_paid:0, balance_due:3200, currency:'KES', issue_date:'2024-06-15', due_date:'2024-06-20', description:'Water bill June 2024 - Unit GF-01', payment_link:pl3, created_at:ago(15)});
  DB.payments.push({id:pay1, organization_id:orgId, payment_reference:'MPESA-QHB24KAT2X', invoice_id:i1, tenant_id:t1, unit_id:un1, property_id:p1, amount:45000, currency:'KES', method:'mpesa_stk', status:'completed', mpesa_receipt_number:'QHB24KAT2X', mpesa_phone_number:'254722111001', receipt_number:'RCP-'+Date.now(), reconciled:true, payment_date:ago(20), created_at:ago(20)});
  DB.maintenance.push({id:uid(), organization_id:orgId, request_number:'MNT-2024-001', title:'Broken water tap in bathroom', description:'Hot water tap leaking', category:'plumbing', priority:'high', status:'in_progress', unit_id:un1, property_id:p1, tenant_id:t1, assigned_to:u2, created_at:ago(5)});
  DB.maintenance.push({id:uid(), organization_id:orgId, request_number:'MNT-2024-002', title:'Power socket not working in bedroom', description:'Double socket near bed not working', category:'electrical', priority:'medium', status:'open', unit_id:un2, property_id:p1, tenant_id:t2, created_at:ago(2)});
  DB.maintenance.push({id:uid(), organization_id:orgId, request_number:'MNT-2024-003', title:'Main gate lock jammed', description:'Cannot open gate with provided key', category:'security', priority:'emergency', status:'open', unit_id:un4, property_id:p2, tenant_id:t3, created_at:ago(1)});
  DB.meters.push({id:uid(), organization_id:orgId, unit_id:un1, property_id:p1, meter_type:'water', meter_number:'WTR001', previous_reading:1220, current_reading:1258, consumption:38, unit_rate:85, fixed_charge:200, total_amount:3430, reading_date:'2024-06-30', created_at:ago(1)});
  DB.meters.push({id:uid(), organization_id:orgId, unit_id:un2, property_id:p1, meter_type:'electricity', meter_number:'ELC002', previous_reading:4500, current_reading:4618, consumption:118, unit_rate:22, fixed_charge:500, total_amount:3096, reading_date:'2024-06-30', created_at:ago(1)});
  DB.expenses.push({id:uid(), organization_id:orgId, property_id:p1, category:'maintenance', description:'Plumber call-out fee and parts', amount:8500, currency:'KES', expense_date:'2024-06-10', vendor_name:'Nairobi Plumbing Services', created_at:ago(20)});
  DB.expenses.push({id:uid(), organization_id:orgId, property_id:p1, category:'utilities', description:'Common area electricity bill', amount:12000, currency:'KES', expense_date:'2024-06-28', vendor_name:'Kenya Power', created_at:ago(2)});

  return orgId;
}

function getDashboard(orgId) {
  const props = byOrg(DB.properties,orgId).filter(p=>p.is_active);
  const units = byOrg(DB.units,orgId).filter(u=>u.is_active);
  const pays  = byOrg(DB.payments,orgId).filter(p=>p.status==='completed');
  const invs  = byOrg(DB.invoices,orgId);
  const maint = byOrg(DB.maintenance,orgId);
  const occ   = units.filter(u=>u.status==='occupied').length;
  const vac   = units.filter(u=>u.status==='vacant').length;
  const ovrd  = invs.filter(i=>i.status==='overdue');
  const now   = new Date();
  const mtd   = pays.filter(p=>{ const d=new Date(p.payment_date); return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear(); });
  const tenIds= [...new Set(byOrg(DB.leases,orgId).filter(l=>l.status==='active').map(l=>l.tenant_id))];
  return {
    properties:{total:props.length,active:props.length},
    units:{total:units.length,occupied:occ,vacant:vac,maintenance:0,occupancy_rate:units.length?+((occ/units.length)*100).toFixed(1):0},
    tenants:{total:tenIds.length},
    revenue:{this_month:mtd.reduce((s,p)=>s+p.amount,0),last_month:198000},
    overdue:{count:ovrd.length,amount:ovrd.reduce((s,i)=>s+parseFloat(i.balance_due||0),0)},
    maintenance:{open:maint.filter(m=>m.status==='open').length,in_progress:maint.filter(m=>m.status==='in_progress').length},
    collection_rate:85.5,
    monthly_revenue:[{month:'Jan 2024',revenue:198000},{month:'Feb 2024',revenue:213000},{month:'Mar 2024',revenue:198000},{month:'Apr 2024',revenue:221000},{month:'May 2024',revenue:198000},{month:'Jun 2024',revenue:mtd.reduce((s,p)=>s+p.amount,0)||45000}],
    recent_payments:pays.slice(-5).reverse().map(p=>{ const t=DB.users.find(u=>u.id===p.tenant_id); const u=DB.units.find(x=>x.id===p.unit_id); const pr=DB.properties.find(x=>x.id===p.property_id); return {...p,tenant_name:t?t.first_name+' '+t.last_name:'',unit_number:u&&u.unit_number,property_name:pr&&pr.name}; }),
    expiring_leases:[],
  };
}

seed();

// ── HTTP Server ───────────────────────────────────────────────
const server = http.createServer(async (req,res) => {
  const parsed = url.parse(req.url,true);
  const p      = parsed.pathname;
  const method = req.method;

  if (method==='OPTIONS') { res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type,Authorization','Access-Control-Allow-Methods':'GET,POST,PUT,PATCH,DELETE,OPTIONS'}); return res.end(); }

  // Static HTML pages
  if (p==='/'||p==='/login') return servFile(res, path.join(PUBLIC,'login.html'));
  if (p==='/app'||p.startsWith('/app')) return servFile(res, path.join(PUBLIC,'app.html'));

  // Payment portal
  if (p.startsWith('/pay/')) {
    const invNum = p.split('/pay/')[1];
    const inv = DB.invoices.find(i=>i.invoice_number===invNum);
    if (!inv) { res.writeHead(302,{Location:'/'}); return res.end(); }
    const t=DB.users.find(u=>u.id===inv.tenant_id), u=DB.units.find(x=>x.id===inv.unit_id), pr=DB.properties.find(x=>x.id===inv.property_id), org=DB.organizations.find(o=>o.id===inv.organization_id);
    // Serve portal page with data injected
    try {
      let html = fs.readFileSync(path.join(PUBLIC,'portal.html'),'utf8');
      const d = JSON.stringify({...inv,tenant_name:t?t.first_name+' '+t.last_name:'',unit_number:u&&u.unit_number,property_name:pr&&pr.name,org_name:org&&org.name,mpesa_shortcode:org&&org.mpesa_shortcode});
      html = html.replace('__INVOICE_DATA__', d);
      res.writeHead(200,{'Content-Type':'text/html'}); return res.end(html);
    } catch { res.writeHead(302,{Location:'/'}); return res.end(); }
  }

  if (!p.startsWith('/api/')) { res.writeHead(302,{Location:'/'}); return res.end(); }

  const body   = ['POST','PUT','PATCH'].includes(method) ? await parseBody(req) : {};
  const auth   = getAuth(req);
  const orgId  = auth&&auth.organizationId;
  const userId = auth&&auth.userId;
  const api    = p.replace('/api','');

  // ── AUTH ──────────────────────────────────────────────────
  if (api==='/auth/login' && method==='POST') {
    const user = DB.users.find(u=>u.email===(body.email||'').toLowerCase().trim());
    if (!user||!checkPw(body.password,user.password_hash)) return json(res,{error:'Invalid email or password'},401);
    if (!user.is_active) return json(res,{error:'Account inactive'},401);
    const org = DB.organizations.find(o=>o.id===user.organization_id);
    const tok = makeToken({userId:user.id,organizationId:user.organization_id,role:user.role});
    return json(res,{accessToken:tok,refreshToken:tok,user:{id:user.id,email:user.email,firstName:user.first_name,lastName:user.last_name,role:user.role,phone:user.phone},organization:{id:org&&org.id,name:org&&org.name,plan:org&&org.subscription_plan,status:org&&org.subscription_status,currency:org&&org.currency,timezone:org&&org.timezone}});
  }
  if (api==='/auth/me' && method==='GET') {
    if (!auth) return json(res,{error:'Unauthorized'},401);
    const u=DB.users.find(u=>u.id===userId), o=DB.organizations.find(o=>o.id===orgId);
    if(!u) return json(res,{error:'Not found'},404);
    return json(res,{...u,password_hash:undefined,org_id:o&&o.id,org_name:o&&o.name,subscription_plan:o&&o.subscription_plan,subscription_status:o&&o.subscription_status,currency:o&&o.currency,timezone:o&&o.timezone});
  }

  if (!auth) return json(res,{error:'Unauthorized'},401);

  // ── DASHBOARD ─────────────────────────────────────────────
  if (api==='/dashboard/summary' && method==='GET') return json(res,getDashboard(orgId));

  // ── PROPERTIES ───────────────────────────────────────────
  if (api==='/properties' && method==='GET') {
    const props = byOrg(DB.properties,orgId).map(p=>({...p,occupied_units:DB.units.filter(u=>u.property_id===p.id&&u.status==='occupied').length,total_units:DB.units.filter(u=>u.property_id===p.id).length}));
    return json(res,{data:props,pagination:{total:props.length,page:1,pages:1}});
  }
  if (api==='/properties' && method==='POST') {
    const prop={id:uid(),organization_id:orgId,owner_id:userId,name:body.name,type:body.type||'residential',address:body.address,city:body.city||'Nairobi',country:body.country||'Kenya',current_valuation:parseFloat(body.currentValuation)||0,total_units:0,occupied_units:0,is_active:true,created_at:new Date().toISOString()};
    DB.properties.push(prop); return json(res,prop,201);
  }

  // ── UNITS ────────────────────────────────────────────────
  if (api==='/units/vacant' && method==='GET') return json(res,byOrg(DB.units,orgId).filter(u=>u.status==='vacant'));
  if (api==='/units' && method==='GET') {
    let units=byOrg(DB.units,orgId);
    if(parsed.query.status) units=units.filter(u=>u.status===parsed.query.status);
    if(parsed.query.propertyId) units=units.filter(u=>u.property_id===parsed.query.propertyId);
    const enriched=units.map(u=>{ const t=u.current_tenant_id?DB.users.find(x=>x.id===u.current_tenant_id):null; const pr=DB.properties.find(x=>x.id===u.property_id); const bl=u.block_id?DB.blocks.find(x=>x.id===u.block_id):null; return{...u,tenant_name:t?t.first_name+' '+t.last_name:null,tenant_phone:t&&t.phone,property_name:pr&&pr.name,block_name:bl&&bl.name}; });
    return json(res,{data:enriched,pagination:{total:enriched.length,page:1,pages:1}});
  }
  if (api==='/units' && method==='POST') {
    const unit={id:uid(),organization_id:orgId,unit_number:body.unitNumber,type:body.type||'1br',monthly_rent:parseFloat(body.monthlyRent)||0,deposit_amount:parseFloat(body.depositAmount)||0,property_id:body.propertyId,block_id:body.blockId||null,bedrooms:body.bedrooms||0,bathrooms:body.bathrooms||1,status:'vacant',is_active:true,created_at:new Date().toISOString()};
    DB.units.push(unit); return json(res,unit,201);
  }

  // ── BLOCKS ───────────────────────────────────────────────
  if (api==='/blocks' && method==='GET') return json(res,byOrg(DB.blocks,orgId));
  if (api==='/blocks' && method==='POST') { const bl={id:uid(),organization_id:orgId,...body,created_at:new Date().toISOString()}; DB.blocks.push(bl); return json(res,bl,201); }

  // ── TENANTS ──────────────────────────────────────────────
  if (api==='/tenants' && method==='GET') {
    const tenants=byOrg(DB.users,orgId).filter(u=>u.role==='tenant').map(t=>{ const l=DB.leases.find(l=>l.tenant_id===t.id&&l.status==='active'); const u=l?DB.units.find(x=>x.id===l.unit_id):null; const pr=u?DB.properties.find(x=>x.id===u.property_id):null; return{...t,password_hash:undefined,lease_status:l&&l.status,unit_number:u&&u.unit_number,property_name:pr&&pr.name}; });
    return json(res,{data:tenants,pagination:{total:tenants.length,page:1,pages:1}});
  }
  if (api.match(/^\/tenants\/[^/]+$/) && method==='GET') {
    const id=api.split('/')[2]; const t=DB.users.find(u=>u.id===id&&u.organization_id===orgId);
    if(!t) return json(res,{error:'Not found'},404);
    return json(res,{...t,password_hash:undefined,invoices:DB.invoices.filter(i=>i.tenant_id===id).slice(0,10)});
  }
  if (api==='/tenants' && method==='POST') {
    const tmp='Temp'+Math.random().toString(36).slice(-6)+'!';
    const t={id:uid(),organization_id:orgId,role:'tenant',first_name:body.firstName,last_name:body.lastName,email:body.email,phone:body.phone,national_id:body.nationalId,kra_pin:body.kraPin,password_hash:hashPw(tmp),is_active:true,created_at:new Date().toISOString()};
    DB.users.push(t); return json(res,{...t,password_hash:undefined,temporaryPassword:tmp},201);
  }

  // ── LEASES ───────────────────────────────────────────────
  if (api==='/leases' && method==='GET') {
    const leases=byOrg(DB.leases,orgId).map(l=>{ const t=DB.users.find(u=>u.id===l.tenant_id); const u=DB.units.find(x=>x.id===l.unit_id); const pr=DB.properties.find(x=>x.id===l.property_id); return{...l,tenant_name:t?t.first_name+' '+t.last_name:'',tenant_phone:t&&t.phone,unit_number:u&&u.unit_number,property_name:pr&&pr.name}; });
    return json(res,{data:leases});
  }
  if (api==='/leases' && method==='POST') {
    const u=DB.units.find(x=>x.id===body.unitId);
    const l={id:uid(),organization_id:orgId,unit_id:body.unitId,tenant_id:body.tenantId,property_id:u&&u.property_id,lease_number:'LSE-'+Date.now(),status:'active',start_date:body.startDate,end_date:body.endDate,monthly_rent:parseFloat(body.monthlyRent)||0,deposit_amount:parseFloat(body.depositAmount)||0,rent_due_day:5,grace_period_days:5,late_fee_type:'percentage',late_fee_value:10,created_at:new Date().toISOString()};
    DB.leases.push(l);
    if(u){u.status='occupied';u.current_tenant_id=body.tenantId;u.current_lease_id=l.id;}
    return json(res,l,201);
  }
  if (api.match(/^\/leases\/[^/]+\/terminate$/) && method==='PATCH') {
    const l=DB.leases.find(x=>x.id===api.split('/')[2]&&x.organization_id===orgId);
    if(!l) return json(res,{error:'Not found'},404);
    l.status='terminated'; l.move_out_date=body.moveOutDate;
    const u=DB.units.find(x=>x.id===l.unit_id);
    if(u){u.status='vacant';u.current_tenant_id=null;u.current_lease_id=null;}
    return json(res,l);
  }

  // ── INVOICES ─────────────────────────────────────────────
  if (api==='/invoices' && method==='GET') {
    let invs=byOrg(DB.invoices,orgId);
    if(parsed.query.status) invs=invs.filter(i=>i.status===parsed.query.status);
    if(parsed.query.type)   invs=invs.filter(i=>i.type===parsed.query.type);
    const e=invs.map(i=>{ const t=DB.users.find(u=>u.id===i.tenant_id); const u=DB.units.find(x=>x.id===i.unit_id); const pr=DB.properties.find(x=>x.id===i.property_id); return{...i,tenant_name:t?t.first_name+' '+t.last_name:'',unit_number:u&&u.unit_number,property_name:pr&&pr.name}; });
    return json(res,{data:e.sort((a,b)=>new Date(b.created_at)-new Date(a.created_at)),pagination:{total:e.length}});
  }
  if (api==='/invoices' && method==='POST') {
    const num='INV-'+new Date().getFullYear()+'-'+String(DB.invoices.length+1).padStart(5,'0');
    const pl='http://localhost:'+PORT+'/pay/'+num;
    const total=(parseFloat(body.amount)||0)+(parseFloat(body.taxAmount)||0)-(parseFloat(body.discountAmount)||0);
    const inv={id:uid(),organization_id:orgId,invoice_number:num,type:body.type||'rent',status:'sent',tenant_id:body.tenantId,unit_id:body.unitId,lease_id:body.leaseId,property_id:body.propertyId,amount:parseFloat(body.amount)||0,total_amount:total,balance_due:total,amount_paid:0,currency:body.currency||'KES',issue_date:body.issueDate,due_date:body.dueDate,description:body.description,payment_link:pl,created_at:new Date().toISOString()};
    DB.invoices.push(inv); return json(res,inv,201);
  }
  if (api==='/invoices/bulk-generate-rent' && method==='POST') {
    const mo=parseInt(body.billingMonth)||(new Date().getMonth()+1), yr=parseInt(body.billingYear)||new Date().getFullYear();
    const created=[];
    for(const l of byOrg(DB.leases,orgId).filter(x=>x.status==='active')){
      if(DB.invoices.find(i=>i.lease_id===l.id&&i.type==='rent'&&new Date(i.issue_date).getMonth()+1===mo&&new Date(i.issue_date).getFullYear()===yr)) continue;
      const num='INV-'+yr+String(mo).padStart(2,'0')+'-'+String(DB.invoices.length+1).padStart(4,'0');
      const inv={id:uid(),organization_id:orgId,invoice_number:num,type:'rent',status:'sent',tenant_id:l.tenant_id,unit_id:l.unit_id,lease_id:l.id,property_id:l.property_id,amount:l.monthly_rent,total_amount:l.monthly_rent,balance_due:l.monthly_rent,amount_paid:0,currency:'KES',issue_date:yr+'-'+String(mo).padStart(2,'0')+'-01',due_date:yr+'-'+String(mo).padStart(2,'0')+'-05',payment_link:'http://localhost:'+PORT+'/pay/'+num,created_at:new Date().toISOString()};
      DB.invoices.push(inv); created.push(inv);
    }
    return json(res,{message:'Generated '+created.length+' rent invoices',invoices:created});
  }
  if (api.match(/^\/invoices\/[^/]+\/void$/) && method==='PATCH') {
    const inv=DB.invoices.find(i=>i.id===api.split('/')[2]&&i.organization_id===orgId);
    if(!inv) return json(res,{error:'Not found'},404);
    inv.status='void'; return json(res,inv);
  }
  if (api.match(/^\/invoices\/[^/]+\/send$/) && method==='POST') {
    const inv=DB.invoices.find(i=>i.id===api.split('/')[2]&&i.organization_id===orgId);
    if(!inv) return json(res,{error:'Not found'},404);
    inv.sent_at=new Date().toISOString();
    return json(res,{message:'Invoice sent (Demo: no real email/SMS in demo mode)'});
  }

  // ── PAYMENTS ─────────────────────────────────────────────
  if (api==='/payments' && method==='GET') {
    const pays=byOrg(DB.payments,orgId).map(p=>{ const t=DB.users.find(u=>u.id===p.tenant_id); const u=DB.units.find(x=>x.id===p.unit_id); const pr=DB.properties.find(x=>x.id===p.property_id); const i=DB.invoices.find(x=>x.id===p.invoice_id); return{...p,tenant_name:t?t.first_name+' '+t.last_name:'',unit_number:u&&u.unit_number,property_name:pr&&pr.name,invoice_number:i&&i.invoice_number}; });
    return json(res,{data:pays.sort((a,b)=>new Date(b.payment_date)-new Date(a.payment_date)),pagination:{total:pays.length}});
  }
  if (api==='/payments/manual' && method==='POST') {
    let inv=DB.invoices.find(i=>i.id===body.invoiceId&&i.organization_id===orgId);
    if(!inv) inv=DB.invoices.find(i=>i.invoice_number===body.invoiceNumber&&i.organization_id===orgId);
    if(!inv) return json(res,{error:'Invoice not found - check the Invoice ID or Invoice Number'},404);
    const amt=parseFloat(body.amount)||parseFloat(inv.balance_due)||0;
    const rec='RCP-'+Date.now();
    const pay={id:uid(),organization_id:orgId,payment_reference:(body.method||'cash').toUpperCase()+'-'+Date.now(),invoice_id:inv.id,tenant_id:inv.tenant_id,unit_id:inv.unit_id,property_id:inv.property_id,amount:amt,currency:inv.currency||'KES',method:body.method||'cash',status:'completed',bank_reference:body.bankReference,receipt_number:rec,reconciled:true,payment_date:new Date().toISOString(),created_at:new Date().toISOString()};
    DB.payments.push(pay);
    inv.amount_paid=(parseFloat(inv.amount_paid)||0)+amt;
    inv.balance_due=Math.max(0,(parseFloat(inv.total_amount)||0)-inv.amount_paid);
    inv.status=inv.balance_due<=0?'paid':'partially_paid';
    if(inv.status==='paid') inv.paid_at=new Date().toISOString();
    return json(res,pay,201);
  }
  if (api==='/payments/mpesa/stk-push' && method==='POST') {
    const inv=DB.invoices.find(i=>i.id===body.invoiceId&&i.organization_id===orgId);
    if(!inv) return json(res,{error:'Invoice not found'},404);
    const cid='ws_CO_DEMO_'+Date.now();
    const pay={id:uid(),organization_id:orgId,payment_reference:'MPESA-'+cid,invoice_id:inv.id,tenant_id:inv.tenant_id,unit_id:inv.unit_id,property_id:inv.property_id,amount:parseFloat(body.amount)||inv.total_amount,currency:'KES',method:'mpesa_stk',status:'pending',mpesa_phone_number:body.phoneNumber,payment_date:new Date().toISOString(),created_at:new Date().toISOString()};
    DB.payments.push(pay);
    return json(res,{checkoutRequestId:cid,message:'STK Push sent (Demo mode - add real Daraja credentials for live M-Pesa)',payment:pay});
  }
  if (api.match(/^\/payments\/portal\/[^/]+$/) && method==='GET') {
    const invNum=api.split('/')[3];
    const inv=DB.invoices.find(i=>i.invoice_number===invNum);
    if(!inv) return json(res,{error:'Not found'},404);
    const t=DB.users.find(u=>u.id===inv.tenant_id), u=DB.units.find(x=>x.id===inv.unit_id), pr=DB.properties.find(x=>x.id===inv.property_id), org=DB.organizations.find(o=>o.id===inv.organization_id);
    return json(res,{...inv,tenant_name:t?t.first_name+' '+t.last_name:'',unit_number:u&&u.unit_number,property_name:pr&&pr.name,org_name:org&&org.name,mpesa_shortcode:org&&org.mpesa_shortcode});
  }

  // ── MAINTENANCE ──────────────────────────────────────────
  if (api==='/maintenance' && method==='GET') {
    let reqs=byOrg(DB.maintenance,orgId);
    if(parsed.query.status) reqs=reqs.filter(r=>r.status===parsed.query.status);
    const e=reqs.map(r=>{ const t=DB.users.find(u=>u.id===r.tenant_id); const u=DB.units.find(x=>x.id===r.unit_id); const pr=DB.properties.find(x=>x.id===r.property_id); const a=r.assigned_to?DB.users.find(u=>u.id===r.assigned_to):null; return{...r,tenant_name:t?t.first_name+' '+t.last_name:'',unit_number:u&&u.unit_number,property_name:pr&&pr.name,assigned_name:a?a.first_name+' '+a.last_name:'Unassigned'}; });
    return json(res,{data:e.sort((a,b)=>new Date(b.created_at)-new Date(a.created_at))});
  }
  if (api==='/maintenance' && method==='POST') {
    const u=body.unitId?DB.units.find(x=>x.id===body.unitId):null;
    const r={id:uid(),organization_id:orgId,request_number:'MNT-'+Date.now(),title:body.title,description:body.description||body.title,category:body.category||'other',priority:body.priority||'medium',status:'open',unit_id:body.unitId,property_id:u&&u.property_id,tenant_id:body.tenantId||userId,created_at:new Date().toISOString()};
    DB.maintenance.push(r); return json(res,r,201);
  }
  if (api.match(/^\/maintenance\/[^/]+\/complete$/) && method==='PATCH') {
    const r=DB.maintenance.find(x=>x.id===api.split('/')[2]&&x.organization_id===orgId);
    if(!r) return json(res,{error:'Not found'},404);
    r.status='completed'; r.completed_date=new Date().toISOString(); r.actual_cost=body.actualCost; r.work_done=body.workDone;
    return json(res,r);
  }
  if (api.match(/^\/maintenance\/[^/]+\/assign$/) && method==='PATCH') {
    const r=DB.maintenance.find(x=>x.id===api.split('/')[2]&&x.organization_id===orgId);
    if(!r) return json(res,{error:'Not found'},404);
    r.status='assigned'; r.assigned_to=body.assignedTo; r.scheduled_date=body.scheduledDate;
    return json(res,r);
  }

  // ── METERS ───────────────────────────────────────────────
  if (api==='/meters' && method==='GET') {
    const m=byOrg(DB.meters,orgId).map(m=>{ const u=DB.units.find(x=>x.id===m.unit_id); const pr=DB.properties.find(x=>x.id===m.property_id); return{...m,unit_number:u&&u.unit_number,property_name:pr&&pr.name}; });
    return json(res,m);
  }
  if (api==='/meters' && method==='POST') {
    const u=DB.units.find(x=>x.id===body.unitId);
    const cons=(parseFloat(body.currentReading)||0)-(parseFloat(body.previousReading)||0);
    const total=cons*(parseFloat(body.unitRate)||85)+(parseFloat(body.fixedCharge)||0);
    const m={id:uid(),organization_id:orgId,unit_id:body.unitId,property_id:u&&u.property_id,meter_type:body.meterType||'water',meter_number:body.meterNumber||'MTR-001',previous_reading:parseFloat(body.previousReading)||0,current_reading:parseFloat(body.currentReading)||0,consumption:cons,unit_rate:parseFloat(body.unitRate)||85,fixed_charge:parseFloat(body.fixedCharge)||0,total_amount:total,reading_date:body.readingDate||new Date().toISOString().split('T')[0],read_by:userId,created_at:new Date().toISOString()};
    DB.meters.push(m); return json(res,m,201);
  }

  // ── EXPENSES ─────────────────────────────────────────────
  if (api==='/expenses' && method==='GET') {
    const e=byOrg(DB.expenses,orgId).map(e=>{ const pr=e.property_id?DB.properties.find(x=>x.id===e.property_id):null; return{...e,property_name:pr&&pr.name}; });
    return json(res,{data:e.sort((a,b)=>new Date(b.expense_date)-new Date(a.expense_date))});
  }
  if (api==='/expenses' && method==='POST') {
    const e={id:uid(),organization_id:orgId,property_id:body.propertyId,category:body.category,description:body.description,amount:parseFloat(body.amount)||0,currency:'KES',expense_date:body.expenseDate||new Date().toISOString().split('T')[0],vendor_name:body.vendorName,created_by:userId,created_at:new Date().toISOString()};
    DB.expenses.push(e); return json(res,e,201);
  }

  // ── REPORTS ──────────────────────────────────────────────
  if (api==='/reports/rent-collection' && method==='GET') {
    const data=byOrg(DB.invoices,orgId).filter(i=>i.type==='rent').map(i=>{ const t=DB.users.find(u=>u.id===i.tenant_id); const u=DB.units.find(x=>x.id===i.unit_id); const pr=DB.properties.find(x=>x.id===i.property_id); return{...i,tenant:t?t.first_name+' '+t.last_name:'',unit_number:u&&u.unit_number,property:pr&&pr.name}; });
    const summary={total:data.length,collected:data.filter(i=>i.status==='paid').length,outstanding:data.filter(i=>i.status!=='paid').length,totalAmount:data.reduce((s,i)=>s+parseFloat(i.total_amount||0),0),collectedAmount:data.reduce((s,i)=>s+parseFloat(i.amount_paid||0),0)};
    return json(res,{data,summary});
  }
  if (api==='/reports/occupancy' && method==='GET') {
    return json(res,byOrg(DB.properties,orgId).map(pr=>{ const units=DB.units.filter(u=>u.property_id===pr.id&&u.is_active); const occ=units.filter(u=>u.status==='occupied').length; return{property:pr.name,total_units:units.length,occupied:occ,vacant:units.length-occ,occupancy_rate:units.length?+((occ/units.length)*100).toFixed(1):0}; }));
  }
  if (api==='/reports/income-statement' && method==='GET') {
    const pays=byOrg(DB.payments,orgId).filter(p=>p.status==='completed');
    const income=[{type:'rent',total:pays.reduce((s,p)=>s+p.amount,0)}].filter(i=>i.total>0);
    const ec={};
    byOrg(DB.expenses,orgId).forEach(e=>{ec[e.category]=(ec[e.category]||0)+parseFloat(e.amount||0);});
    const expenses=Object.entries(ec).map(([category,total])=>({category,total}));
    const ti=income.reduce((s,i)=>s+i.total,0), te=expenses.reduce((s,e)=>s+e.total,0);
    return json(res,{income,expenses,totalIncome:ti,totalExpenses:te,netIncome:ti-te});
  }
  if (api==='/reports/utility-bills' && method==='GET') return json(res,byOrg(DB.meters,orgId));

  // ── USERS ────────────────────────────────────────────────
  if (api==='/users' && method==='GET') return json(res,{data:byOrg(DB.users,orgId).filter(u=>u.role!=='tenant').map(u=>({...u,password_hash:undefined}))});
  if (api==='/users' && method==='POST') { const tmp='Temp'+Math.random().toString(36).slice(-6)+'!'; const u={id:uid(),organization_id:orgId,role:body.role,first_name:body.firstName,last_name:body.lastName,email:body.email,phone:body.phone,password_hash:hashPw(tmp),is_active:true,created_at:new Date().toISOString()}; DB.users.push(u); return json(res,{...u,password_hash:undefined,temporaryPassword:tmp},201); }

  // ── ORGANIZATIONS ────────────────────────────────────────
  if (api==='/organizations/settings' && method==='GET') return json(res,DB.organizations.find(o=>o.id===orgId)||{});
  if (api==='/organizations/settings' && method==='PUT') { const org=DB.organizations.find(o=>o.id===orgId); if(org) Object.assign(org,{name:body.name,phone:body.phone,address:body.address,city:body.city,country:body.country,timezone:body.timezone,currency:body.currency,mpesa_shortcode:body.mpesaShortcode}); return json(res,org||{}); }

  // ── SUBSCRIPTIONS ────────────────────────────────────────
  if (api==='/subscriptions/plans' && method==='GET') return json(res,[{id:'1',name:'Starter',slug:'starter',price_monthly:29,price_annually:290,max_properties:5,max_units:50,features:['basic_reports','sms','qr_payments']},{id:'2',name:'Professional',slug:'professional',price_monthly:79,price_annually:790,max_properties:20,max_units:200,features:['advanced_reports','mpesa','stripe','whatsapp','maintenance']},{id:'3',name:'Enterprise',slug:'enterprise',price_monthly:199,price_annually:1990,features:['all_features','api_access','white_label']}]);
  if (api==='/subscriptions/current' && method==='GET') { const org=DB.organizations.find(o=>o.id===orgId); return json(res,{plan_name:org&&org.subscription_plan,status:org&&org.subscription_status}); }

  if (api==='/documents' && method==='GET') return json(res,[]);
  if (api==='/documents' && method==='POST') return json(res,{id:uid(),...body,created_at:new Date().toISOString()},201);
  if (api==='/notifications' && method==='GET') return json(res,{data:[]});

  return json(res,{error:'Not found: '+method+' '+api},404);
});

server.listen(PORT, () => {
  console.log('\n');
  console.log('╔════════════════════════════════════════════════╗');
  console.log('║    SmartProperty ERP - LIVE DEMO RUNNING       ║');
  console.log('╠════════════════════════════════════════════════╣');
  console.log('║                                                ║');
  console.log('║  Open browser:  http://localhost:3000          ║');
  console.log('║                                                ║');
  console.log('║  LOGIN CREDENTIALS:                            ║');
  console.log('║  Email:    admin@demo.com                      ║');
  console.log('║  Password: demo1234                            ║');
  console.log('║                                                ║');
  console.log('║  Also try:                                     ║');
  console.log('║  manager@demo.com  /  demo1234                 ║');
  console.log('║  jane@tenant.com   /  demo1234                 ║');
  console.log('║                                                ║');
  console.log('║  Payment portals (open in browser):            ║');
  console.log('║  http://localhost:3000/pay/INV-2024-00001      ║');
  console.log('║  http://localhost:3000/pay/INV-2024-00002      ║');
  console.log('║                                                ║');
  console.log('║  Press Ctrl+C to stop                          ║');
  console.log('╚════════════════════════════════════════════════╝');
  console.log('');
});
server.on('error',err=>{ if(err.code==='EADDRINUSE'){console.error('Port '+PORT+' in use. Kill other process first.');} else{console.error(err);} process.exit(1); });
