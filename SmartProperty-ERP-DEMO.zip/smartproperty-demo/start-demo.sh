#!/bin/bash
clear
echo ""
echo " ================================================"
echo "  SmartProperty ERP - Starting Demo Server..."
echo " ================================================"
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo " ERROR: Node.js is not installed!"
    echo ""
    echo " Please install Node.js from: https://nodejs.org"
    echo " Download the LTS version, install it, then run this again."
    echo ""
    exit 1
fi

echo " Node.js $(node --version) found. Starting server..."
echo ""
echo " ================================================"
echo "  LOGIN CREDENTIALS:"
echo "  Email:    admin@demo.com"
echo "  Password: demo1234"
echo ""
echo "  Also try:"
echo "  manager@demo.com  /  demo1234"
echo "  jane@tenant.com   /  demo1234"
echo ""
echo "  Payment portals:"
echo "  http://localhost:3000/pay/INV-2024-00001"
echo "  http://localhost:3000/pay/INV-2024-00002"
echo ""
echo "  Press Ctrl+C to stop"
echo " ================================================"
echo ""

# Open browser after 3 seconds (background)
(sleep 3 && (open http://localhost:3000 2>/dev/null || xdg-open http://localhost:3000 2>/dev/null)) &

# Start server
node src/server.js
