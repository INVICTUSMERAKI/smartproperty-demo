╔══════════════════════════════════════════════════════════════╗
║         SmartProperty ERP — Live Demo                        ║
║         Zero dependencies · Pure Node.js · Runs instantly    ║
╚══════════════════════════════════════════════════════════════╝

This is a fully working demo of SmartProperty ERP.
It runs entirely on YOUR computer — no internet needed after setup.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REQUIREMENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Only ONE thing needed: Node.js (free)
  Download from: https://nodejs.org
  Click the big "LTS" button. Install it. That's all.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HOW TO START
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Windows:
  Double-click START-DEMO.bat
  Browser opens automatically at http://localhost:3000

Mac / Linux:
  Open Terminal in this folder
  Type: bash start-demo.sh
  Browser opens automatically at http://localhost:3000

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
LOGIN CREDENTIALS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Super Admin (full access):
  Email:    admin@demo.com
  Password: demo1234

Property Manager:
  Email:    manager@demo.com
  Password: demo1234

Tenant (limited view):
  Email:    jane@tenant.com
  Password: demo1234

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DEMO DATA INCLUDED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  2 Properties    (Westlands Heights + Kilimani Court)
  5 Units         (Mix of occupied and vacant)
  3 Tenants       (Jane Wanjiku, Brian Mwangi, Amina Hassan)
  2 Active Leases
  3 Invoices      (1 paid, 1 overdue, 1 water bill)
  1 M-Pesa payment recorded
  3 Maintenance requests (various priorities)
  2 Meter readings (water + electricity)
  2 Expenses

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PAYMENT PORTAL (no login needed)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Open these URLs directly in your browser to see
how tenants pay without logging in:

  http://localhost:3000/pay/INV-2024-00001  (Paid invoice)
  http://localhost:3000/pay/INV-2024-00002  (Overdue invoice)
  http://localhost:3000/pay/INV-2024-00003  (Water bill)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WHAT YOU CAN DO IN THE DEMO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  ✅ View dashboard KPIs and revenue chart
  ✅ Browse properties and units
  ✅ Register new tenants
  ✅ Create invoices (auto-generates pay link)
  ✅ Record payments (M-Pesa, bank, cash)
  ✅ Submit and complete maintenance requests
  ✅ Record meter readings (auto-calculates bill)
  ✅ Record expenses
  ✅ View rent collection and occupancy reports
  ✅ Open public payment portal (QR code payments)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
NOTE: This is a demo — data resets on restart
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The demo stores all data in memory. When you stop
and restart the server, data resets to the original
demo data. This is intentional for demo purposes.

The full production version uses PostgreSQL and
Docker so data persists permanently.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Interested in the full source code?
Visit: your-selar-link-here
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
