@echo off
title SmartProperty ERP - Demo
color 1F
echo.
echo  ================================================
echo   SmartProperty ERP - Starting Demo Server...
echo  ================================================
echo.

:: Check if Node.js is installed
node --version >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Node.js is not installed!
    echo.
    echo  Please download and install Node.js from:
    echo  https://nodejs.org  (click the LTS version)
    echo.
    echo  After installing Node.js, run this file again.
    echo.
    pause
    exit /b 1
)

echo  Node.js found. Starting server...
echo.
echo  ================================================
echo   Opening browser in 3 seconds...
echo  ================================================
echo.
echo  LOGIN CREDENTIALS:
echo  Email:    admin@demo.com
echo  Password: demo1234
echo.
echo  Also try:
echo  manager@demo.com  /  demo1234
echo  jane@tenant.com   /  demo1234
echo.
echo  Press Ctrl+C to stop the server
echo  ================================================
echo.

:: Wait 3 seconds then open browser
timeout /t 3 /nobreak >nul
start http://localhost:3000

:: Start the server
node src/server.js

pause
